# لَمّة شات

تطبيق Android باسم لَمّة شات.

- package: `com.lammachat.app`
- Firebase config: `app/google-services.json`
- GitHub Actions builds a debug APK and uploads it as an artifact.

بعد رفع المشروع إلى GitHub، افتح Actions وشغّل **Build Lamma Chat APK**. بعد نجاح البناء ستجد APK في Artifacts.
